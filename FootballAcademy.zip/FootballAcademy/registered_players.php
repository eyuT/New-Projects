<?php
session_start();
require 'db_conn.php'; // Database connection

// Check login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = isset($_SESSION['username']) ? $_SESSION['username'] : "Guest";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Registered Athletes - Football Academy</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body {
    background: url('images/football-field-bg.jpg') center/cover no-repeat fixed;
    min-height: 100vh;
    font-family: 'Poppins', sans-serif;
}
.navbar { background-color: rgba(0,0,0,0.8); }
.navbar-brand { font-weight: bold; color: #fff !important; }
.logout-btn {
    background: #dc3545;
    color: white;
    border-radius: 25px;
    padding: 6px 16px;
    border: none;
}
.table-container {
    background-color: rgba(0,0,0,0.7);
    padding: 20px;
    border-radius: 15px;
    color: white;
    margin-top: 50px;
}
.table th {
    color: white;
    background-color: #155724; /* Dark green header */
}
.table td {
    background-color: #28a745; /* Green background for rows */
    color: white;
}
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
        <i class="bi bi-trophy-fill text-warning me-2"></i> Football Academy
    </a>
    <div class="ms-auto">
      <span class="text-white me-3 fw-semibold">Welcome, <?php echo ucfirst($username); ?>!</span>
      <a href="logout.php" class="btn logout-btn">Logout</a>
    </div>
  </div>
</nav>

<!-- Registered Athletes Table -->
<div class="container table-container">
    <h2 class="text-center mb-4">🏅 Registered Athletes</h2>
    
    <div class="table-responsive">
        <table class="table table-bordered table-striped text-center">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>DOB</th>
                    <th>Gender</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Joined Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM Athlete ORDER BY athlete_id DESC";
                $result = $conn->query($query);
                
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>".$row['athlete_id']."</td>
                            <td>".$row['first_name']."</td>
                            <td>".$row['last_name']."</td>
                            <td>".$row['dob']."</td>
                            <td>".$row['gender']."</td>
                            <td>".$row['email']."</td>
                            <td>".$row['phone']."</td>
                            <td>".$row['address']."</td>
                            <td>".$row['joined_date']."</td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>No athletes registered yet.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>