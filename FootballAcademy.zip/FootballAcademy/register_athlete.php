<?php
session_start();
require 'db_conn.php'; // Database connection

// Check login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Handle form submission
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = $_POST['first_name'] ?? '';
    $last_name = $_POST['last_name'] ?? '';
    $dob = $_POST['dob'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';

    // Simple validation
    if ($first_name && $last_name && $dob && $gender) {
        $stmt = $conn->prepare("INSERT INTO Athlete (first_name, last_name, dob, gender, email, phone, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $first_name, $last_name, $dob, $gender, $email, $phone, $address);
        if ($stmt->execute()) {
            $message = "Athlete registered successfully!";
        } else {
            $message = "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $message = "Please fill in all required fields.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Register Athlete - Football Academy</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    background: url('images/football-field-bg.jpg') center/cover no-repeat fixed;
    min-height: 100vh;
    font-family: 'Poppins', sans-serif;
}
.navbar { background-color: rgba(0,0,0,0.8); }
.navbar-brand { font-weight: bold; color: #fff !important; }
.logout-btn {
    background: #dc3545;
    color: white;
    border-radius: 25px;
    padding: 6px 16px;
    border: none;
}
.btn-submit {
    background-color: #198754;
    color: white;
    border: none;
    border-radius: 25px;
    padding: 10px 25px;
    font-weight: 600;
}
.btn-submit:hover { background-color: #157347; }
.form-container {
    background-color: rgba(0,0,0,0.7);
    padding: 30px;
    border-radius: 15px;
    color: white;
    max-width: 600px;
    margin: 50px auto;
}
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
        <i class="bi bi-trophy-fill text-warning me-2"></i> Football Academy
    </a>
    <div class="ms-auto">
      <a href="logout.php" class="btn logout-btn">Logout</a>
    </div>
  </div>
</nav>

<!-- Registration Form -->
<div class="form-container">
    <h2 class="text-center mb-4">Register Athlete</h2>

    <?php if($message): ?>
        <div class="alert alert-info"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label for="first_name" class="form-label">First Name *</label>
            <input type="text" class="form-control" name="first_name" required>
        </div>
        <div class="mb-3">
            <label for="last_name" class="form-label">Last Name *</label>
            <input type="text" class="form-control" name="last_name" required>
        </div>
        <div class="mb-3">
            <label for="dob" class="form-label">Date of Birth *</label>
            <input type="date" class="form-control" name="dob" required>
        </div>
        <div class="mb-3">
            <label for="gender" class="form-label">Gender *</label>
            <select class="form-control" name="gender" required>
                <option value="">Select</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" name="email">
        </div>
        <div class="mb-3">
            <label for="phone" class="form-label">Phone</label>
            <input type="text" class="form-control" name="phone">
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Address</label>
            <textarea class="form-control" name="address"></textarea>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-submit">Register Athlete</button>
        </div>
    </form>
</div>

</body>
</html>