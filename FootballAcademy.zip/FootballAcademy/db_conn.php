<?php
$servername = "localhost";
$dbusername = "root";
$dbpassword = ""; // XAMPP default
$dbname     = "football_academy_db";

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>