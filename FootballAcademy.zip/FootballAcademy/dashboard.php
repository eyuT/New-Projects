<?php
session_start();
require 'db_conn.php'; // database connection

// Check login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = isset($_SESSION['username']) ? $_SESSION['username'] : "Guest";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Football Academy Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>
body {
    background: url('images/football-field-bg.jpg') center/cover no-repeat fixed;
    min-height: 100vh;
    font-family: 'Poppins', sans-serif;
}
.navbar { background-color: rgba(0,0,0,0.8); }
.navbar-brand { font-weight: bold; color: #fff !important; }
.logout-btn {
    background: #dc3545;
    color: white;
    border-radius: 25px;
    padding: 6px 16px;
    border: none;
}
.star-btn {
    background-color: #198754;
    color: white;
    border: none;
    border-radius: 30px;
    padding: 8px 18px;
    font-weight: 600;
    margin-left: 15px;
    transition: background-color 0.3s ease;
}
.star-btn:hover { background-color: #157347; }
.card { border-radius: 15px; overflow: hidden; transition: transform 0.3s ease; }
.card:hover { transform: translateY(-5px); }
.section-title {
    color: white;
    font-weight: 600;
    text-shadow: 2px 2px 6px rgba(0,0,0,0.5);
    margin-bottom: 20px;
}
.player-img, .academy-img {
    width: 600px;
    height: 500px;
    object-fit: cover;
    display: block;
    margin-left: auto;
    margin-right: auto;
    border-radius: 15px;
}
</style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <div class="d-flex align-items-center flex-wrap">
      <a class="navbar-brand d-flex align-items-center" href="#">
        <i class="bi bi-trophy-fill text-warning me-2"></i> Football Academy
      </a>
      
      <!-- Buttons -->
      <a href="star_players.php" class="btn star-btn">
        <i class="bi bi-star-fill text-warning"></i> Star Players
      </a>
      <a href="training_types.php" class="btn star-btn">
        <i class="bi bi-bounding-box-circles"></i> Types of Training
      </a>
      <a href="register_athlete.php" class="btn star-btn">
        <i class="bi bi-person-plus-fill"></i> Register Athlete
      </a>
     
      
      <a href="registered_players.php" class="btn star-btn">
        <i class="bi bi-list-ul"></i> Registered Players
      </a>
    </div>
    <div class="d-flex ms-auto align-items-center">
      <span class="text-white me-3 fw-semibold">Welcome, <?php echo ucfirst($username); ?>!</span>
      <a href="logout.php" class="btn logout-btn">Logout</a>
    </div>
  </div>
</nav>

<!-- Dashboard Content -->
<div class="container mt-5">

  <!-- Player Highlights -->
  <h2 class="section-title text-center">🏃‍♂️ Player Highlights</h2>
  <div class="row g-4 justify-content-center">
    <div class="col-md-4 d-flex justify-content-center">
      <div class="card shadow-lg">
        <img src="images/player1.jpg" class="player-img" alt="Player 1">
        <div class="card-body text-center">
          <h5 class="card-title">Elias Taye</h5>
          <p class="card-text">Forward | Top Scorer | Age: 18</p>
        </div>
      </div>
    </div>
    <div class="col-md-4 d-flex justify-content-center">
      <div class="card shadow-lg">
        <img src="images/player2.jpg" class="player-img" alt="Player 2">
        <div class="card-body text-center">
          <h5 class="card-title">Daniel Mulu</h5>
          <p class="card-text">Midfielder | Creative Playmaker | Age: 17</p>
        </div>
      </div>
    </div>
    <div class="col-md-4 d-flex justify-content-center">
      <div class="card shadow-lg">
        <img src="images/player3.jpg" class="player-img" alt="Player 3">
        <div class="card-body text-center">
          <h5 class="card-title">Abel Kidane</h5>
          <p class="card-text">Goalkeeper | 5 Clean Sheets | Age: 19</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Training Schedule -->
  <h2 class="section-title text-center mt-5">📅 Training Schedule</h2>
  <div class="row g-4">
    <div class="col-md-6">
      <div class="card shadow text-center bg-success text-white">
        <div class="card-body">
          <h5 class="card-title">Morning Session</h5>
          <p class="card-text">Time: 7:00 AM - 9:00 AM</p>
          <p class="card-text">Focus: Fitness & Dribbling</p>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card shadow text-center bg-warning text-dark">
        <div class="card-body">
          <h5 class="card-title">Evening Session</h5>
          <p class="card-text">Time: 4:00 PM - 6:00 PM</p>
          <p class="card-text">Focus: Passing & Match Practice</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Academy Moments -->
  <h2 class="section-title text-center mt-5">📸 Academy Moments</h2>
  <div class="row g-3 mb-5 justify-content-center">
    <div class="col-md-4 d-flex justify-content-center">
      <img src="images/training1.jpg" class="academy-img shadow" alt="Training 1">
    </div>
    <div class="col-md-4 d-flex justify-content-center">
      <img src="images/training2.jpg" class="academy-img shadow" alt="Training 2">
    </div>
    <div class="col-md-4 d-flex justify-content-center">
      <img src="images/training3.jpg" class="academy-img shadow" alt="Training 3">
    </div>
  </div>

</div>
</body>
</html>
