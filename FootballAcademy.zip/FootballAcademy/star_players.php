<?php
session_start(); 
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$username = isset($_SESSION['username']) ? $_SESSION['username'] : "Guest";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Star Players - Football Academy</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background: url('images/football-field-bg.jpg') center/cover no-repeat fixed;
      min-height: 100vh;
      font-family: 'Poppins', sans-serif;
    }
    .navbar {
      background-color: rgba(0, 0, 0, 0.8);
    }
    .navbar-brand {
      font-weight: bold;
      color: #fff !important;
    }
    .logout-btn {
      background: #dc3545;
      color: white;
      border-radius: 25px;
      padding: 6px 16px;
      border: none;
    }
    .star-btn {
      background-color: #198754;
      color: white;
      border: none;
      border-radius: 30px;
      padding: 8px 18px;
      font-weight: 600;
      margin-left: 15px;
      transition: background-color 0.3s ease;
    }
    .star-btn:hover {
      background-color: #157347;
    }
    .card {
      border-radius: 15px;
      overflow: hidden;
      transition: transform 0.3s ease;
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .section-title {
      color: white;
      font-weight: 600;
      text-shadow: 2px 2px 6px rgba(0,0,0,0.5);
      margin-bottom: 20px;
    }
    /* Star player images - fixed size */
    .star-img {
      width: 300px;    /* fixed width */
      height: 500px;   /* fixed height */
      object-fit: cover; /* fill the box without distortion */
      display: block;
      margin-left: auto;
      margin-right: auto;
      border-radius: 15px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <div class="d-flex align-items-center">
      <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
        <i class="bi bi-trophy-fill text-warning me-2"></i> Football Academy
      </a>
      <a href="star_players.php" class="btn star-btn">
        <i class="bi bi-star-fill text-warning"></i> Star Players
      </a>
      <a href="training_types.php" class="btn star-btn">
        <i class="bi bi-bounding-box-circles"></i> Types of Training
      </a>
    </div>
    <div class="d-flex ms-auto align-items-center">
      <span class="text-white me-3 fw-semibold">Welcome, <?php echo ucfirst($username); ?>!</span>
      <a href="logout.php" class="btn logout-btn">Logout</a>
    </div>
  </div>
</nav>

<!-- Star Players Content -->
<div class="container mt-5">
  <h2 class="section-title text-center">⭐ Top 5 Star Players</h2>
  <div class="row g-4 justify-content-center">
    <!-- Player 1 -->
    <div class="col-md-6 col-lg-4 d-flex justify-content-center">
      <div class="card shadow-lg">
        <img src="images/player1.jpg" class="card-img-top star-img" alt="Player 1">
        <div class="card-body text-center">
          <h5 class="card-title">Elias Taye</h5>
          <p class="card-text">Forward | Top Scorer | Age: 18</p>
        </div>
      </div>
    </div>
    <!-- Player 2 -->
    <div class="col-md-6 col-lg-4 d-flex justify-content-center">
      <div class="card shadow-lg">
        <img src="images/player2.jpg" class="card-img-top star-img" alt="Player 2">
        <div class="card-body text-center">
          <h5 class="card-title">Daniel Mulu</h5>
          <p class="card-text">Midfielder | Creative Playmaker | Age: 17</p>
        </div>
      </div>
    </div>
    <!-- Player 3 -->
    <div class="col-md-6 col-lg-4 d-flex justify-content-center">
      <div class="card shadow-lg">
        <img src="images/player3.jpg" class="card-img-top star-img" alt="Player 3">
        <div class="card-body text-center">
          <h5 class="card-title">Abel Kidane</h5>
          <p class="card-text">Goalkeeper | 5 Clean Sheets | Age: 19</p>
        </div>
      </div>
    </div>
    <!-- Player 4 -->
    <div class="col-md-6 col-lg-4 d-flex justify-content-center">
      <div class="card shadow-lg">
        <img src="images/player4.jpg" class="card-img-top star-img" alt="Player 4">
        <div class="card-body text-center">
          <h5 class="card-title">Samuel Bekele</h5>
          <p class="card-text">Defender | Strong Tackler | Age: 18</p>
        </div>
      </div>
    </div>
    <!-- Player 5 -->
    <div class="col-md-6 col-lg-4 d-flex justify-content-center">
      <div class="card shadow-lg">
        <img src="images/player5.jpg" class="card-img-top star-img" alt="Player 5">
        <div class="card-body text-center">
          <h5 class="card-title">Yared Tadesse</h5>
          <p class="card-text">Winger | Fast & Agile | Age: 17</p>
        </div>
      </div>
    </div>
  </div>

  <div class="text-center mt-5">
    <a href="dashboard.php" class="btn btn-success px-4">
      <i class="bi bi-arrow-left"></i> Back to Dashboard
    </a>
  </div>
</div>

</body>
</html>