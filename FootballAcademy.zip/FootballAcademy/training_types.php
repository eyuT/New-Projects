
<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Types of Training - Football Academy</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      background: url('images/football-field-bg.jpg') center/cover no-repeat fixed;
      min-height: 100vh;
      font-family: 'Poppins', sans-serif;
    }
    .navbar {
      background-color: rgba(0, 0, 0, 0.8);
    }
    .navbar-brand {
      font-weight: bold;
      color: #fff !important;
    }
    .logout-btn {
      background: #dc3545;
      color: white;
      border-radius: 25px;
      padding: 6px 16px;
      border: none;
    }
    .card {
      border-radius: 15px;
      overflow: hidden;
      transition: transform 0.3s ease;
      background-color: #fff;
    }
    .card:hover {
      transform: translateY(-5px);
    }
    .section-title {
      color: white;
      font-weight: 600;
      text-shadow: 2px 2px 6px rgba(0,0,0,0.5);
      margin-bottom: 30px;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <div class="d-flex align-items-center">
      <a class="navbar-brand d-flex align-items-center" href="dashboard.php">
        <i class="bi bi-trophy-fill text-warning me-2"></i> Football Academy
      </a>
      <a href="star_players.php" class="btn star-btn">
        <i class="bi bi-star-fill text-warning"></i> Star Players
      </a>
      <a href="training_types.php" class="btn star-btn">
        <i class="bi bi-bounding-box-circles"></i> Types of Training
      </a>
    </div>
    <div class="d-flex ms-auto align-items-center">
      <span class="text-white me-3 fw-semibold">Welcome, <?php echo ucfirst($_SESSION['username']); ?>!</span>
      <a href="logout.php" class="btn logout-btn">Logout</a>
    </div>
  </div>
</nav>

<!-- Content -->
<div class="container mt-5">
  <h2 class="section-title text-center">⚽ Types of Football Training</h2>
  <div class="row g-4 mb-5">
    <div class="col-md-4">
      <div class="card shadow-lg text-center p-3">
        <i class="bi bi-shield-fill-check text-success fs-1 mb-3"></i>
        <h5 class="card-title">Defensive Training</h5>
        <p class="card-text">Improve tackles, marking, positioning, and defensive awareness.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-lg text-center p-3">
        <i class="bi bi-rocket-takeoff-fill text-danger fs-1 mb-3"></i>
        <h5 class="card-title">Attacking Training</h5>
        <p class="card-text">Focus on finishing, dribbling, crossing, and attacking movement.</p>
      </div>
    </div>
    <div class="col-md-4">
      <div class="card shadow-lg text-center p-3">
        <i class="bi bi-lightning-fill text-warning fs-1 mb-3"></i>
        <h5 class="card-title">Speed & Agility</h5>
        <p class="card-text">Enhance sprinting, reaction time, and agility for match performance.</p>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card shadow-lg text-center p-3">
        <i class="bi bi-heart-pulse-fill text-info fs-1 mb-3"></i>
        <h5 class="card-title">Fitness & Endurance</h5>
        <p class="card-text">Improve stamina, strength, and overall physical condition.</p>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card shadow-lg text-center p-3">
        <i class="bi bi-people-fill text-primary fs-1 mb-3"></i>
        <h5 class="card-title">Team Tactics</h5>
        <p class="card-text">Practice positioning, formations, and team coordination on the pitch.</p>
      </div>
    </div>
  </div>
  <div class="text-center mb-5">
    <a href="dashboard.php" class="btn btn-success px-4"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
  </div>
</div>

</body>
</html>